import uuid
from random import random

from django.core.mail import send_mail
from django.core.paginator import Paginator, EmptyPage
from django.shortcuts import render
from django.shortcuts import render, HttpResponse, redirect
from django.urls import reverse
from django.conf import settings

from sac_app.check_code import gen_check_code


from io import BytesIO
from django.contrib import auth
import requests
from functools import wraps

from sac_app.models import notices, students, managers, organizers, activities


def login(request):
    if request.method == 'POST':
        method = request.POST.get('select')    #获取登录信息
        log_id = request.POST.get('username')
        log_password = request.POST.get('password')
        con_code = request.POST.get('idcode')
        check_code = request.session.get('check_code')
        print(method)
        print(log_id)
        print(log_password)
        print(con_code)
        print(check_code)
        if con_code.upper() == check_code.upper():
            if method == 'stu':  # 如果选择学生登录
                try:
                    student = students.objects.get(stu_id=log_id)
                    if student.stu_valid == 1:
                        if student.stu_password == log_password:
                            request.session['user_id'] = student.stu_id
                            request.session['user_type'] = 'student'
                            return redirect(reverse('sac_app:stu_home'))
                        else:
                            return render(request, 'login.html', {'password_error': '密码错误'})
                    else:
                        return render(request, 'login.html', {'valid_error': '账户未激活'})
                except:
                    return render(request, 'login.html', {'id_error': 'id不存在'})
            elif method == 'org':  # 如果选择组织者登录
                try:
                    organizer = organizers.objects.get(org_id=log_id)
                    if organizer.org_password == log_password:
                        request.session['user_id'] = organizer.org_id
                        request.session['user_type'] = 'organizer'
                        return HttpResponse('登陆成功')
                    else:
                        return render(request, 'login.html', {'password_error': '密码错误'})
                except:
                    return render(request, 'login.html', {'id_error': 'id不存在'})
            elif method == 'mag':  # 如果选择管理者登录
                try:
                    manager = managers.objects.get(man_id=log_id)
                    if manager.man_password == log_password:
                        request.session['user_id'] = manager.man_id
                        request.session['user_type'] = 'manager'
                        return HttpResponse('登陆成功')
                    else:
                        return render(request, 'login.html', {'password_error': '密码错误'})
                except:
                    return render(request, 'login.html', {'id_error': 'id不存在'})
        else:
            return render(request,'login.html',{'code_error':'验证码错误'})

    else:
        return render(request, "login.html")
# Create your views here.
# Create your views here.

def register(request):
    if request.method == 'POST':
        re_id = request.POST.get('username')    #获取注册信息
        re_Email = request.POST.get('email')
        re_password = request.POST.get('password')
        con_password = request.POST.get('agpassword')
        con_code = request.POST.get('idcode')
        check_code = request.session.get('check_code')

        if con_code.upper() == check_code.upper():
            if re_password == con_password:
                try:
                    student = students.objects.get(stu_id=re_id)
                    return render(request, 'register.html', {'id_error': '该id已存在'})
                except:
                    try:
                        student = students.objects.get(stu_Email=re_Email)
                        return render(request, 'register.html', {'Email_error': '该Email已被占用'})
                    except:
                        student = students.objects.create(stu_id=re_id, stu_Email=re_Email,
                                                          stu_password=re_password,stu_valid = 0)
                        token = str(uuid.uuid4()).replace('-', '')  # 生成随机字符串
                        request.session[token] = re_id  # session利用生成的随机字符串存储用户id
                        subject = '学生账号激活'
                        message = '''
                                                欢迎注册使用学生活动中心！亲爱的用户赶快激活使用吧！
                                                <br>http://127.0.0.1:8000/sac_app/active?token={}
                                                <br>
                                                                        学生活动中心开发团队
                                                '''.format(token)
                        send_mail(subject=subject, message='', from_email='2912784728@qq.com',
                                  recipient_list=[re_Email], html_message=message)  # 给用户邮箱发送用于激活的邮件
                        return HttpResponse('注册成功，请前去激活')
            else:
                return render(request, 'register.html', {'password_error': '两次输入密码不同'})
        else:
            return render(request,'register.html',{'code_error':'验证码错误'})
    else:
        return render(request,'register.html')

    return render(request,'register.html')



def stu_active(request):
    token = request.GET.get('token')
    re_id = request.session.get(token)
    student = students.objects.get(stu_id = re_id)
    student.stu_valid = 1
    student.save()
    return render(request,"stu_active.html")

def forgetpwd(request):
    """
    忘记密码页
    """
    if request.method == 'POST':
        re_id = request.POST.get('username')
        re_Email = request.POST.get('email')
        code = request.POST.get('idcode')
        real_code = request.session.get('check_code')
        if students.objects.filter(stu_id=re_id).count == 0:
            return render(request, 'forgetpwd.html', {'no_stu_error': '用户不存在'})
        if code.upper() != real_code.upper():
            return render(request, 'forgetpwd.html', {'check_code_error': '验证码错误'})
        else:
            students.objects.get(stu_id=re_id)
            token = str(uuid.uuid4()).replace('-', '')
            request.session[token] = re_id
            subject = '修改密码'
            # 超链接里面的链接地址根据实际情况修改（修改密码的链接）
            message = '''
                                        ！
                                        <br>http://127.0.0.1:8000/sac_app/changepwd?token={}
                                        <br>
                                                                学生活动中心开发团队
                        '''.format(token)
            send_mail(subject=subject, message='', from_email='2912784728@qq.com',
                      recipient_list=[re_Email], html_message=message)
            return redirect(reverse("sac_app:login"))  # 重定向到登录界面
    else:
        return render(request, "forgetpwd.html")




def check_code(request):
    img, code = gen_check_code()
    obj = BytesIO()
    print(obj.getvalue())
    img.save(obj, format='png')
    request.session['check_code'] = code  # 将验证码保存到session里面
    return HttpResponse(obj.getvalue())

def stu_home(request):
    """
    学生：主页
    :param request:
    :return:
    """
    return render(request, 'stu_home/stu_home.html')


def stu_activity(request):
    """
    学生：活动大厅
    :param request:
    :return:
    """
    return render(request, 'stu_home/stu_activity.html')


def stu_join_activity(request):
    """
    学生：已参加活动
    :param request:
    :return:
    """
    return render(request, 'stu_home/stu_join_activity.html')

def stu_center(request):
    """
    学生：个人中心
    :param request:
    :return:
    """
    return render(request, 'stu_home/stu_center.html')

def stu_activity_yes(request):
    """
    学生：可参加活动
    :param request:
    :return:
    """
    return render(request, 'stu_home/stu_activity_yes.html')


def stu_activity_no(request):
    """
    学生：不可参加队伍
    :param request:
    :return:
    """
    return render(request, 'stu_home/stu_activity_no.html')




def stu_createteam(request):
    """
    学生：学生创建队伍
    :param request:
    :return:
    """
    return render(request, 'stu_home/stu_createteam.html')


def stu_myteam(request):
    """
    学生：我的队伍
    :param request:
    :return:
    """
    return render(request, 'stu_home/stu_myteam.html')


def stu_otherteam(request):
    """
    学生：其他队伍
    :param request:
    :return:
    """
    return render(request, 'stu_home/stu_otherteam.html')

def stu_notice(request):
    """
    学生：公告界面
    :param request:
    :return:
    """
    return render(request, 'stu_home/stu_notice.html')

def stu_notice_act(request):
    """
    学生：公告界面
    :param request:
    :return:
    """

    return render(request, 'stu_home/stu_notice_act.html',locals())

def stu_notice_sys(request):
    """
    学生：公告界面
    :param request:
    :return:
    """

    return render(request, 'stu_home/stu_notice_sys.html',locals())


def org_home(request):
    """
    组织者：主页
    :param request:
    :return:
    """
    return render(request, 'org_home/org_home.html')


def org_launch_activity(request):
    """
    组织者：发布活动
    :param request:
    :return:
    """
    return render(request, 'org_home/org_launch_activity.html')


def org_launch_notice(request):
    """
    组织者：发布公告
    :param request:
    :return:
    """
    return render(request, 'org_home/org_launch_notice.html')


def org_modify_activity(request):
    """
    组织者：修改活动
    :param request:
    :return:
    """
    return render(request, 'org_home/org_modify_activity.html')


def org_view_pasted_activity(request):
    """
    组织者：查看已发布活动
    :param request:
    :return:
    """
    return render(request, 'org_home/org_view_posted_activity.html')

def org_notice(request):
    """
    组织者: 公告界面
    :param request:
    :return:
    """
    return render(request, 'org_home/org_notice.html')

def org_notice_act(request):
    """
    组织者：活动公告界面
    :param request:
    :return:
    """

    return render(request, 'org_home/org_notice_act.html',locals())

def org_notice_sys(request):
    """
    组织者：系统公告界面
    :param request:
    :return:
    """

    return render(request, 'org_home/org_notice_sys.html',locals())



def mag_home(request):
    """
    管理者：主页
    :param request:
    :return:
    """
    return render(request, 'mag_home/mag_home.html')


def mag_examine_act(request):
    """
    管理者：审核
    :param request:
    :return:
    """
    try:
        pagesize = 10


        #if request.method == "POST":
        # 获取 url 后面的 page 参数的值, 首页不显示 page 参数, 默认值是 1
        #page = request.POST.get('page',1)
        qs1 = activities.objects.all()#.values().order_by('org_id')#'notice_title')
        pgnt1 = Paginator(qs1, pagesize)
        page = request.POST.get('page',1)
       # print(pgnt1.num_pages)
        #print(pgnt1.count)
        page1 = pgnt1.page(page)
        #print(page)
        #print(page1)
        act_list = list(page1)
        #print(act_list)
        return HttpResponse(render(request, 'mag_home/mag_examine_act.html',locals()))
    except EmptyPage:
        return HttpResponse(render(request, 'mag_home/mag_examine_act.html', {'org_list': []}))
    except:
        return HttpResponse(render(request,'mag_home/mag_examine_act.html', {'msg': "未知错误"}))
    return render(request, 'mag_home/mag_examine_act.html')

def mag_examine_org(request):
    """
    管理者：审核
    :param request:
    :return:
    """
    try:
        pagesize = 10

        #if request.method == "POST":
        # 获取 url 后面的 page 参数的值, 首页不显示 page 参数, 默认值是 1
        #page = request.POST.get('page',1)
        qs1 = organizers.objects.all()#.values().order_by('org_id')#'notice_title')
        pgnt1 = Paginator(qs1, pagesize)
        page = request.POST.get('page',1)
        #print(pgnt1.num_pages)
        #print(pgnt1.count)
        page1 = pgnt1.page(page)
        #print(page)
        #print(page1)
        org_list = list(page1)
        #print(org_list)
        return HttpResponse(render(request, 'mag_home/mag_examine_org.html',locals()))
    except EmptyPage:
        return HttpResponse(render(request, 'mag_home/mag_examine_org.html', {'org_list': []}))
    except:
        return HttpResponse(render(request,'mag_home/mag_examine_org.html', {'msg': "未知错误"}))
    return render(request, 'mag_home/mag_examine_org.html')

def mag_add_org(request):
    """
    管理者：审核
    :param request:
    :return:
    """
    if request.method == 'POST':
        id = request.POST.get('id')
        name = request.POST.get('name')
        header_name = request.POST.get('header_name')
        password = request.POST.get('password')
        header_phone =request.POST.get('header_phone')
        header_college = request.POST.get('header_college')
        introduction = request.POST.get('introduction')
        organizers.objects.create(org_id = id,org_name=name, org_header_name=header_name,
                                  org_password=password,org_header_phone =header_phone,
        org_header_college=header_college,org_introduction = introduction)
        return render(request, 'mag_home/mag_add_org.html',{"success":"添加成功"})

    return render(request, 'mag_home/mag_add_org.html')


def mag_manage(request):
    """
    管理者：管理组织者
    :param request:
    :return:
    """
    try:
        pagesize = 10

        #if request.method == "POST":
        # 获取 url 后面的 page 参数的值, 首页不显示 page 参数, 默认值是 1
        #page = request.POST.get('page',1)
        qs1 = organizers.objects.all()#.values().order_by('org_id')#'notice_title')
        pgnt1 = Paginator(qs1, pagesize)
        page = request.POST.get('page',1)
        #print(pgnt1.num_pages)
        #print(pgnt1.count)
        page1 = pgnt1.page(page)
        #print(page)
        #print(page1)
        org_list = list(page1)
        #print(org_list)
        return HttpResponse(render(request, 'mag_home/mag_manage.html',locals()))
    except EmptyPage:
        return HttpResponse(render(request, 'mag_home/mag_manage.html', {'org_list': []}))
    except:
        return HttpResponse(render(request,'mag_home/mag_manage.html', {'msg': "未知错误"}))
    return render(request, 'mag_home/mag_manage.html')


def mag_launch_notice(request):
    if request.method == 'POST':
        id = request.POST.get('id')
        title = request.POST.get('title')
        content = request.POST.get('content')
        attachment = request.POST.get('attachment')
        notices.objects.create(notice_id = id,notice_title=title, notice_content=content, notice_appendix=attachment,notice_tag = 0)
        return render(request, 'mag_home/mag_launch_notice.html',{"success":"发布成功"})
    return render(request, 'mag_home/mag_launch_notice.html')


def mag_notice(request):
    """
    管理者：公告界面
    :param request:
    :return:
    """

    try:
        #for i in range(0,17):
            #notices.objects.create(notice_id=i+16, notice_title=random(),
                                   #notice_content=random(),notice_tag = 0)
        #for i in range(0,17):
            #notices.objects.create(notice_id=i+33, notice_title=random(),
                                   #notice_content=random(),notice_tag = 1)
        pagesize = 10

        #if request.method == "POST":
            # 获取 url 后面的 page 参数的值, 首页不显示 page 参数, 默认值是 1
            #page = request.POST.get('page',1)

        qs1 = notices.objects.filter(notice_tag=1).values().order_by('notice_id')#'notice_title')
        qs0 = notices.objects.filter(notice_tag=0).values().order_by('notice_id')#'notice_title')
        pgnt1 = Paginator(qs1, pagesize)
        pgnt0 = Paginator(qs0, pagesize)

        page = request.POST.get('page',1)
        #print(pgnt1.num_pages)
        #print(pgnt1.count)
        #print(pgnt1.num_pages)

        page0 = pgnt0.page(page)
        page1 = pgnt1.page(page)
        notice_sys = list(page0)
        notice_act = list(page1)
        print(notice_act)
        return HttpResponse(render(request, 'mag_home/mag_notice.html',locals()))

    except EmptyPage:
        return HttpResponse(render(request, 'mag_home/mag_notice.html', {'notice_act': [], 'notice_sys': []}))
    except:
        return HttpResponse(render(request,'mag_home/mag_notice.html', {'msg': "未知错误"}))



def mag_notice_act(request,id):
    """
    管理者：公告界面
    :param request:
    :return:
    """
    act = notices.objects.filter(notice_id=id).first()

    return render(request, 'mag_home/mag_notice_act.html',locals())

def mag_notice_sys(request,id):
    """
    管理者：公告界面
    :param request:
    :return:
    """
    sys = notices.objects.filter(notice_id=id).first()
    return render(request, 'mag_home/mag_notice_sys.html',locals())

def changepwd(request):
    """
    修改密码
    :param request:
    :return:
    """
    if request.method == 'POST':
        re_password = request.POST.get('password')
        con_password = request.POST.get('agpassword')
        if re_password != con_password:
            return render(request, 'forgetpwd.html', {'password_error': '密码不一致'})
        else:
            token = request.GET.get('token')
            re_id = request.session.get(token)
            stu1 = students.objects.get(stu_id=re_id)
            stu1.stu_password=re_password
            stu1.save()
            return redirect(reverse("sac_app:stu_home"))  # 重定向到首页
    else:
        return render(request, "changepwd.html")

    return render(request, 'changepwd.html')



def mag_look_act(request,id):
    """
    管理者：公告界面
    :param request:
    :return:
    """
    act = activities.objects.filter(act_id=id).first()

    return render(request, 'mag_home/mag_look_act.html',locals())

def mag_look_org(request,id):
    """
    管理者：公告界面
    :param request:
    :return:
    """
    org = organizers.objects.filter(org_id=id).first()
    return render(request, 'mag_home/mag_look_org.html',locals())

def mag_look_mag_org(request,id):
    """
    管理者：公告界面
    :param request:
    :return:
    """
    org = organizers.objects.filter(org_id=id).first()

    return render(request, 'mag_home/mag_look_mag_org.html',locals())

def mag_revise(request,id):
    """
    管理者：公告界面
    :param request:
    :return:
    """
    org = organizers.objects.filter(org_id=id).first()
    return render(request, 'mag_home/mag_revise.html',locals())
def mag_delete(request,id):
    """
    管理者：公告界面
    :param request:
    :return:
    """
    org = organizers.objects.filter(org_id=id).first()

    return render(request, 'mag_home/mag_delete.html',locals())
