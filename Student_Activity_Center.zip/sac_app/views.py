from django.shortcuts import render
from django.shortcuts import render, HttpResponse, redirect
from django.urls import reverse
from django.conf import settings

from sac_app.check_code import gen_check_code


from io import BytesIO
from django.contrib import auth
import requests
from functools import wraps


def login(request):

    return render(request, "login.html")
# Create your views here.

def register(request):

    return render(request, "register.html")

def forgetpwd(request):

    return render(request, "forgetpwd.html")

def check_code(request):
    img, code = gen_check_code()
    obj = BytesIO()
    print(obj.getvalue())
    img.save(obj, format='png')
    request.session['check_code'] = code  # 将验证码保存到session里面
    return HttpResponse(obj.getvalue())

