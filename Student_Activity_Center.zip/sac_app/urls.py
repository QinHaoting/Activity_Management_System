# coding=utf-8

from django.contrib import admin
from django.urls import path

from . import views

urlpatterns = [
    # path('', admin.site.urls),
    path('login/',views.login),
    path('check_code/',views.check_code),
    path('login/register/',views.register),
    path('login/forgetpwd/',views.forgetpwd),
]